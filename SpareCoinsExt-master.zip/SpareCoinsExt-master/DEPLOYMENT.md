### 1.0.1
 - Manifest (simple)
 - index.html (w/o error)
 - icons

### 1.0.2
 - Manifest (simple)
 - index.html (w/o error)
 - icons
 - background.js
 - beep.wav
 - css/
 - views/

### 1.0.3
 - Manifest (simple)
 - index.html (w/o error)
 - icons
 - background.js
 - beep.wav
 - css/
 - views/
 - js/ ???
 - lib/ ???

(Crashed!)

### 1.0.4
 - Manifest (simple)
 - index.html
 - icons
 - background.js
 - beep.wav
 - css/
 - views/
 - error.html
 - error.js
 - errorListener

### 1.0.5
 - Manifest
 - index.html
 - icons
 - background.js
 - beep.wav
 - css/
 - views/
 - error.html
 - error.js
 - errorListener

(error) This item may not install properly on Chrome 31. Please check the package and the manifest and re-upload if necessary
Cos we're calling background script which isn't loaded?

### 1.0.6
 - Manifest
 - index.html
 - icons
 - background.js
 - beep.wav
 - css/
 - views/
 - error.html
 - error.js
 - errorListener
 - js/
(error) This item may not install properly on Chrome 31. Please check the package and the manifest and re-upload if necessary

### 1.0.7
 - Manifest
 - index.html
 - icons
 - background.js
 - beep.wav
 - css/
 - views/
 - error.html
 - error.js
 - errorListener
 - js/ (w our files)

### 1.0.8
 - Manifest (minified)
 - index.html (minified)
 - icons
 - background.js
 - beep.wav
 - css/
 - views/
 - error.html
 - error.js
 - errorListener
 - js/ (cleaned for size etc)

WORKS!!!

### If finished
 - Description/Images

### Ideas
 - zip too big?
 - somewhere in /lib our files, chrome rolled out an update
 - /lib should be in /js ?
