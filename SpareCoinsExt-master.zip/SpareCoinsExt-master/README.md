### SpareCoins

This is the repo for the front end of the Chrome Extension.

### Build Instructions

**Update manifest version**

**Zip the following files/directories**
 - css/
 - icons/
 - js/
 - lib/
 - views/
 - background.js
 - beep.wav
 - index.html
 - manifest
 - error.html
 - errorListener.js
 - error.js
